<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Funding;
use App\Models\SeniorCitizenFunding;
use Livewire\Attributes\Layout;

#[Layout('layouts.app')]
class Payroll extends Component
{
    public $fundings = [];
    public $selected_funding_id = null;

    public function mount()
    {
        $this->fundings = Funding::where('is_active', true)->get();
        if ($this->fundings->isNotEmpty()) {
            $this->selected_funding_id = $this->fundings->first()->id;
        }
    }

    public function getBeneficiariesProperty()
    {
        if ($this->selected_funding_id) {
            return SeniorCitizenFunding::with('seniorCitizen.barangay', 'funding')
                ->where('funding_id', $this->selected_funding_id)
                ->whereHas('seniorCitizen')
                ->get();
        }
        return collect();
    }

    public function getSelectedFundingProperty()
    {
        if ($this->selected_funding_id) {
            return Funding::find($this->selected_funding_id);
        }
        return null;
    }

    public function render()
    {
        $beneficiaries   = $this->beneficiaries;
        $selectedFunding = $this->selectedFunding;

        $totalSlots     = $selectedFunding ? (int) $selectedFunding->beneficiary : 0;
        $occupiedSlots  = $beneficiaries->count();
        $availableSlots = max(0, $totalSlots - $occupiedSlots);

        return view('livewire.payroll', [
            'beneficiaries'   => $beneficiaries,
            'selectedFunding' => $selectedFunding,
            'totalSlots'      => $totalSlots,
            'occupiedSlots'   => $occupiedSlots,
            'availableSlots'  => $availableSlots,
        ]);
    }
}
